# How this project maps to the Software Engineering PBL

Use this as the skeleton of your PBL report. Each section points to the file or feature that proves it.

## 1. Problem Statement
Colleges receive cybersecurity incidents (phishing, malware, unauthorized access, account compromise, data leakage) through email, calls, WhatsApp or verbally. They are not centrally recorded, classified, assigned, tracked or resolved. *Evidence:* README.md "Problem statement".

## 2. Background / Scenario
Students, faculty and staff use college email, Wi-Fi, portals and shared systems every day. A phishing mail or an infected USB drive can compromise accounts and data. The IT/security team needs one reliable channel and a record of every case. *Evidence:* sample incidents created by `backend/seed.js`.

## 3. Learning Objectives
- Apply the software development life cycle to a real problem.
- Gather and document requirements (functional and non-functional).
- Model the system with UML and DFD.
- Design a layered (3-tier) architecture.
- Implement a full-stack web application (React, Node/Express, MySQL).
- Apply security practices (hashing, JWT, role-based access, validation).
- Test the system with planned test cases.

## 4. Problem Analysis
| Problem | Effect | Addressed by |
|---|---|---|
| Reports scattered across channels | Incidents get lost | Single report form, unique Incident ID |
| No classification | Wrong priority | Type and severity fields, admin can change severity |
| No ownership | Nobody acts | Assign incident to security staff |
| No progress visibility | Reporter keeps asking | Status lifecycle and tracker |
| No history | No accountability | `incident_history` and `incident_notes` tables |
| No management view | No planning | Admin dashboard statistics |

## 5. Proposed Solution
A centralized web portal. Users log in and report incidents with evidence. Administrators review, classify, assign, investigate, resolve and close them. Every action is stored and visible as history. *Lifecycle:* New -> Assigned -> Under Investigation -> Resolved -> Closed.

## 6. Requirements
### Functional requirements
| ID | Requirement | Implemented in |
|---|---|---|
| FR1 | Users log in securely | `authController.login`, `Login.jsx` |
| FR2 | Users report incidents with title, type, description, date, time, severity, location | `ReportIncident.jsx`, `incidentController.createIncident` |
| FR3 | Users attach evidence (image/PDF/doc, max 5 MB) | `middleware/upload.js` |
| FR4 | System generates unique ID `INC-YYYY-NNNN` | `incidentModel.nextIncidentId` |
| FR5 | Users view their own incidents and status | `MyIncidents.jsx`, `UserDashboard.jsx` |
| FR6 | Admin views, searches and filters all incidents | `AdminIncidents.jsx`, `incidentModel.list` |
| FR7 | Admin changes severity | `PUT /api/incidents/:id` |
| FR8 | Admin assigns incident to security staff | `PUT /api/incidents/:id/assign` |
| FR9 | Admin updates status following the lifecycle | `PUT /api/incidents/:id/status` |
| FR10 | Admin adds investigation notes | `POST /api/incidents/:id/notes` |
| FR11 | Admin records resolution and closes incident | status update with resolution |
| FR12 | Admin dashboard statistics | `GET /api/dashboard/stats`, `AdminDashboard.jsx` |
| FR13 | Incident history is maintained | `incident_history` table |
| FR14 | Admin manages users | `ManageUsers.jsx`, `POST /api/users` |
| FR15 | Role-based access (student cannot open admin pages) | `ProtectedRoute.jsx`, `middleware/auth.js` |

### Non-functional requirements
| ID | Requirement | How it is met |
|---|---|---|
| NFR1 Security | Passwords hashed, tokens signed, roles enforced | bcryptjs, JWT, `authorize()` |
| NFR2 Usability | Clean responsive UI, sidebar, badges | `index.css`, Layout |
| NFR3 Reliability | Validation and friendly errors | `errorHandler.js`, validators |
| NFR4 Performance | Page data loads in under 2 seconds locally | Indexed columns, connection pool |
| NFR5 Maintainability | Layered code (routes, controllers, models) | Backend folder structure |
| NFR6 Portability | Runs on any machine with Node and MySQL | README setup steps |
| NFR7 Data integrity | Foreign keys and enums | `database/schema.sql` |

## 7. SRS (outline you can expand)
1. Introduction: purpose, scope, definitions (Incident, Severity, Status), references.
2. Overall description: product perspective (web, 3-tier), user classes (Student/Staff, Security Staff, Admin), operating environment (browser, Node.js, MySQL), constraints, assumptions.
3. Specific requirements: functional (table above), external interfaces (web UI, REST API, MySQL), non-functional (table above).
4. Appendices: use case diagram, DFD, data dictionary (see `database/schema.sql`).

## 8. System Design
Database design: `database/schema.sql` (users, incidents, incident_notes, incident_history with foreign keys). API design: README "API overview". UI design: `frontend/src/pages`. Security design: JWT + roles.

## 9. Software Architecture
Three-tier: React (presentation) -> Express (application) -> MySQL (data). See `docs/diagrams/08-software-architecture.png` and the component diagram.

## 10. UML diagrams (all in `docs/diagrams/`)
| Diagram | File |
|---|---|
| Use Case | 01-use-case-diagram.png |
| Class | 02-class-diagram.png |
| Activity | 03-activity-diagram.png |
| Sequence | 04-sequence-diagram.png |
| Component | 05-component-diagram.png |
| Deployment | 06-deployment-diagram.png |
| DFD level 0 and 1 | 07a-dfd-level0.png, 07b-dfd-level1.png |
| Software Architecture | 08-software-architecture.png |

## 11. Implementation
Frontend: `frontend/src`. Backend: `backend/` (server.js, routes, controllers, models, middleware). Database: `database/schema.sql`, demo data by `backend/seed.js`. Technologies: React 18, Vite, React Router, Axios, Node.js, Express, MySQL, JWT, bcryptjs, multer.

## 12. Testing
22 test cases in `docs/PBL_DOCUMENTATION.md` covering login, invalid login, role access, incident submission, missing fields, ID generation, search, filters, severity, assignment, status, notes, resolution, file validation and logout.

## 13. Test Results
Run each test case during your demo and fill in the "Actual Result" and "Status" columns with what you observe. Add screenshots. Report any failed test honestly with the fix you applied.

## 14. Evaluation
| Objective | Result |
|---|---|
| Central reporting | Achieved: one portal replaces email, calls and WhatsApp |
| Classification and assignment | Achieved: type, severity, assignment fields |
| Tracking and history | Achieved: lifecycle tracker, notes, history timeline |
| Security | Achieved: hashing, JWT, roles, validation |
| Limitations | No email notifications, no password reset, no analytics over time, local deployment only |

## 15. Conclusion
The system gives the college a single, secure place to report and manage cybersecurity incidents. It covers the whole workflow from reporting to closure with role-based control and a full audit trail, and it follows the standard software engineering process of requirements, design, implementation and testing. *Future work:* email/SMS alerts, SLA timers, PDF reports, two-factor authentication, cloud deployment.
