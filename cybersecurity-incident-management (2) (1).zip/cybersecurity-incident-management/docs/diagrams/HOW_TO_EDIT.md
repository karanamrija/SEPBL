# Editing the diagrams

Ready-to-use images are in this folder (PNG for Word/PowerPoint, SVG for sharp scaling).
Open `index.html` in your browser to see them all.

Editable sources are in `source/`:
- `*.mmd` are Mermaid files. To edit in draw.io: **Arrange -> Insert -> Advanced -> Mermaid**, paste the file content.
  Or paste into https://mermaid.live to edit and export.
- `*.dot` are Graphviz files (use case diagram and DFD level 1). Paste into https://dreampuf.github.io/GraphvizOnline to edit and export.

| File | Diagram |
|---|---|
| 01-use-case-diagram | Use Case |
| 02-class-diagram | Class |
| 03-activity-diagram | Activity |
| 04-sequence-diagram | Sequence |
| 05-component-diagram | Component |
| 06-deployment-diagram | Deployment |
| 07a-dfd-level0, 07b-dfd-level1 | Data Flow Diagram |
| 08-software-architecture | Software Architecture |
