# PBL Documentation Support — CyberShield

Ready-made diagram images are in `docs/diagrams/` (open `docs/diagrams/index.html`). The text below explains each diagram and matches the actual implementation (tables, routes, classes).

## 1. Actors
- **Student / Staff** (role `user`) — reports and tracks own incidents.
- **Security Staff** (role `security`) — manages assigned incidents (admin portal, cannot delete or manage users).
- **Admin** (role `admin`) — full control, manages users, can delete incidents.
- **MySQL database** and **File storage (uploads/)** — supporting systems.

## 2. Use Case Diagram
Actors: Student/Staff, Security Staff, Admin (Admin generalizes Security Staff).
- Student/Staff: Login, Logout, View Dashboard, Report Incident (includes *Upload Evidence* [optional extend], *Generate Incident ID*), View My Incidents, View Incident Details / Track Status, View Profile.
- Security Staff: Login, Logout, View Admin Dashboard, View All Incidents, Search/Filter Incidents, View Incident Details, Change Severity, Assign Incident, Update Status, Add Investigation Note, Resolve Incident, Close Incident.
- Admin (in addition): Manage Users (Create/List), Delete Incident.
- Relationships: *Report Incident* «include» *Generate Incident ID*; *Report Incident* «extend» *Upload Evidence*; *Update Status* «include» *Record History*; *Resolve Incident* «include» *Enter Resolution Details*; all use cases except Login «include» *Authenticate (JWT)*.

## 3. Class Diagram
**User**: id, name, email, password(hash), role {user, admin, security}, department, created_at — login(), createUser()
**Incident**: id, incident_id, user_id, title, type, description, severity, status, incident_date, incident_time, location, evidence, assigned_to, resolution, created_at, updated_at — create(), list(), findById(), update(), remove()
**IncidentNote**: id, incident_id, admin_id, note, created_at — addNote(), getNotes()
**IncidentHistory**: id, incident_id, user_id, action, old_value, new_value, created_at — addHistory(), getHistory()
Enumerations: IncidentType (8 values), Severity (Low, Medium, High, Critical), Status (New, Assigned, Under Investigation, Resolved, Closed).
Relationships (multiplicity):
- User 1 — 0..* Incident (reports; `incidents.user_id`)
- User 0..1 — 0..* Incident (assigned to; `incidents.assigned_to`)
- Incident 1 — 0..* IncidentNote (composition); User 1 — 0..* IncidentNote (`admin_id`)
- Incident 1 — 0..* IncidentHistory (composition); User 1 — 0..* IncidentHistory
Controllers (optional layer): AuthController, IncidentController, DashboardController, UserController use models User and Incident.

## 4. Activity Diagram (Incident lifecycle)
Swimlanes: Student/Staff | System | Admin/Security.
Start → [User] Login → Open Report form → Fill details + optional evidence → Submit → [System] Validate input (invalid → show errors, back to form) → Generate Incident ID → Save to MySQL with status *New* → Show "Incident reported successfully." → [Admin] Open dashboard → View new incident → Review & set severity → Assign staff (system sets *Assigned*) → Set *Under Investigation* → Add notes (loop) → Enter resolution → *Resolved* → *Closed* → [System] Update history & statistics → End.
Decision nodes: validation OK?; staff assigned?; resolution entered?

## 5. Sequence Diagram (Report Incident, then Admin management)
Lifelines: User, React UI (ReportIncident page), API (Express routes), Auth middleware, IncidentController, IncidentModel, MySQL.
1. User → UI: fill form, Submit
2. UI → API: POST /api/incidents (multipart + JWT)
3. API → Auth middleware: authenticate(token) → returns user
4. API → multer: store evidence file
5. API → IncidentController: createIncident()
6. Controller: validate fields (alt: invalid → 400 + errors → UI shows error)
7. Controller → IncidentModel: create() → nextIncidentId() → INSERT incidents → INSERT incident_history
8. Model → Controller: new incident (INC-YYYY-NNNN)
9. Controller → UI: 201 "Incident reported successfully."
10. UI → User: show Incident ID.
Second scenario: Admin → UI → PUT /api/incidents/:id/assign → authorize(admin/security) → IncidentController.assignIncident → UserModel.findStaffById → IncidentModel.update + addHistory → 200.

## 6. Component Diagram
Components: **React Frontend** (Pages, Components, AuthContext, API Service/Axios), **Express Backend** (Routes, Middleware [auth, upload, errorHandler], Controllers, Models), **MySQL Database**, **File Storage (uploads/)**.
Interfaces/connections: Frontend → (HTTP/REST JSON via Vite proxy) → Routes; Routes → Middleware → Controllers → Models → (mysql2) → MySQL; upload middleware → File Storage; frontend → `/uploads` static files.
Libraries: jsonwebtoken, bcryptjs, multer, dotenv, cors, mysql2.

## 7. Deployment Diagram
Nodes: **Client Device** (Web browser) — «HTTP» → **Application Server / Developer Laptop** (Node.js runtime: Vite dev server :5173 serving React; Express server :5000; uploads folder) — «TCP 3306 / mysql2» → **Database Server** (MySQL, schema `cyber_incident_management`; on a laptop it is the same machine as localhost).
Artifacts: frontend (React build/Vite), backend (server.js), schema.sql, .env.

## 8. Data Flow Diagram
**Level 0 (Context):** External entities Student/Staff and Admin/Security Staff ↔ one process *Cybersecurity Incident Management System* ↔ data store *Database*. Flows: login credentials, incident report, evidence, incident status/ID, assignment/status/notes/resolution, dashboard statistics, reports.
**Level 1 processes:** 1.0 Authenticate User; 2.0 Report Incident; 3.0 View/Track Incidents; 4.0 Classify & Assign Incident; 5.0 Investigate & Update Status (notes, resolution); 6.0 Generate Dashboard Statistics; 7.0 Manage Users.
**Data stores:** D1 Users, D2 Incidents, D3 Incident Notes, D4 Incident History, D5 Evidence Files.
Flows: 1.0 ↔ D1; 2.0 → D2, D4, D5; 3.0 ← D2, D3; 4.0 ↔ D2, → D4; 5.0 → D2, D3, D4; 6.0 ← D2; 7.0 ↔ D1.

## 9. Software Architecture Diagram
Layered: **Presentation** (React pages/components, React Router, AuthContext, Axios) → **Application** (Express: routes → middleware [JWT auth, role authorization, validation, upload, error handling] → controllers → models) → **Data** (MySQL: users, incidents, incident_notes, incident_history; file system uploads/). Cross-cutting: security (bcrypt, JWT, RBAC), configuration (.env).

## 10. Test Cases
| ID | Scenario | Input | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|
| TC01 | Student login | student@college.com / student123 | Redirect to user dashboard | Redirected to /dashboard | Pass |
| TC02 | Admin login | admin@college.com / admin123 | Redirect to admin dashboard | Redirected to /admin | Pass |
| TC03 | Invalid login | student@college.com / wrong | Error "Invalid email or password." | Error shown | Pass |
| TC04 | Empty login fields | blank email/password | Form blocks submit / "required" message | Blocked | Pass |
| TC05 | Student accesses admin page | Student opens /admin | Redirected to /dashboard | Redirected | Pass |
| TC06 | Student calls admin API | GET /api/users with student token | 403 Access denied | 403 returned | Pass |
| TC07 | Admin access | Admin opens /admin/incidents | All incidents listed | All 9+ listed | Pass |
| TC08 | Submit incident | Valid phishing report | 201, "Incident reported successfully.", ID shown | Success, ID shown | Pass |
| TC09 | Missing fields | Submit with empty title/description | Validation error, nothing saved | 400 / form blocks | Pass |
| TC10 | Incident ID generation | Submit two incidents | IDs INC-YYYY-NNNN, sequential, unique | Sequential IDs | Pass |
| TC11 | Student sees only own incidents | Student opens My Incidents | Only own incidents | Only own shown | Pass |
| TC12 | Search | Admin searches "phishing" | Only matching incidents | Matching only | Pass |
| TC13 | Filter | Status = Under Investigation, Severity = Critical | Only matching incidents | Matching only | Pass |
| TC14 | Severity update | Admin sets severity High | Severity saved, history entry added | Updated | Pass |
| TC15 | Assignment | Admin assigns Ravi Kumar to a New incident | Assigned staff shown, status = Assigned | Updated | Pass |
| TC16 | Status update | Assigned → Under Investigation | Status updated, tracker moves | Updated | Pass |
| TC17 | Invalid status jump | New → Resolved via API | 400 "Invalid status change" | 400 returned | Pass |
| TC18 | Investigation note | Admin adds note | Note listed with name/time | Note shown | Pass |
| TC19 | Resolution | Resolve without details | 400 "Resolution details are required..." | 400 returned | Pass |
| TC20 | Resolve + close | Resolve with details, then Close | Status Resolved then Closed, dashboard counts change | Updated | Pass |
| TC21 | Invalid file | Upload .exe as evidence | 400 "Invalid file type" | 400 returned | Pass |
| TC22 | Logout | Click Logout | Session cleared, redirected to /login; protected pages blocked | Redirected | Pass |

**Note:** The "Actual Result" and "Status" columns describe the expected behaviour of this implementation. Run each test yourself during your demo and replace them with what you observe (add screenshots) before submitting.
