// Creates demo accounts (with bcrypt-hashed passwords) and sample incidents.
// Run with:  npm run seed      (safe to re-run; it resets the data)
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { pool } = require('./config/db');

const USERS = [
  { key: 'admin', name: 'Admin User', email: 'admin@college.com', password: 'admin123', role: 'admin', department: 'IT Security Office' },
  { key: 'sec1', name: 'Ravi Kumar', email: 'security1@college.com', password: 'security123', role: 'security', department: 'IT Security Office' },
  { key: 'sec2', name: 'Priya Sharma', email: 'security2@college.com', password: 'security123', role: 'security', department: 'IT Security Office' },
  { key: 'student', name: 'Aarav Mehta', email: 'student@college.com', password: 'student123', role: 'user', department: 'Computer Science' },
  { key: 'sneha', name: 'Sneha Reddy', email: 'sneha@college.com', password: 'student123', role: 'user', department: 'Electronics' },
  { key: 'faculty', name: 'Dr. Anita Rao', email: 'faculty@college.com', password: 'faculty123', role: 'user', department: 'Mathematics' },
];

const INCIDENTS = [
  { user: 'student', title: 'Phishing email asking for portal credentials', type: 'Phishing', severity: 'High', status: 'New', days: 0, time: '09:15:00', location: 'College Email', desc: 'Received an email claiming to be from the exam cell asking me to verify my student portal password using a link.' },
  { user: 'sneha', title: 'Fake scholarship link shared in WhatsApp group', type: 'Phishing', severity: 'Low', status: 'New', days: 0, time: '11:40:00', location: 'WhatsApp class group', desc: 'A link offering a scholarship was shared in our class group and it opens a page that asks for bank details.' },
  { user: 'sneha', title: 'Suspicious login from unknown location', type: 'Suspicious Login', severity: 'Medium', status: 'Assigned', days: 1, time: '22:30:00', location: 'Student Portal', assigned: 'sec1', desc: 'I received a login alert for my portal account from a city I have never visited.' },
  { user: 'student', title: 'Ransomware pop-up on library computer', type: 'Ransomware', severity: 'Critical', status: 'Assigned', days: 1, time: '14:05:00', location: 'Library PC-12', assigned: 'sec2', desc: 'A full-screen message appeared on the library PC saying files are encrypted and demanding payment.' },
  { user: 'faculty', title: 'Laptop infected after using unknown USB drive', type: 'Malware', severity: 'High', status: 'Under Investigation', days: 2, time: '10:20:00', location: 'Faculty Laptop (Maths Dept)', assigned: 'sec2', note: 'Laptop isolated from the network. Running a full antivirus scan and checking for unauthorized processes.', desc: 'After plugging in a USB drive received at a seminar, my laptop started running slowly and showing unknown pop-ups.' },
  { user: 'sneha', title: 'Student marks spreadsheet shared publicly', type: 'Data Leakage', severity: 'Critical', status: 'Under Investigation', days: 3, time: '16:45:00', location: 'Cloud Drive', assigned: 'sec1', note: 'Public sharing link disabled. Access logs requested to find out who opened the file.', desc: 'A spreadsheet with student marks and roll numbers was found shared with the setting "anyone with the link".' },
  { user: 'student', title: 'Unauthorized access to lab computer account', type: 'Unauthorized Access', severity: 'Medium', status: 'Resolved', days: 4, time: '13:10:00', location: 'Computer Lab 2', assigned: 'sec1', resolution: 'Lab account password reset and shared login disabled. Users reminded to log out after each session.', note: 'Verified logs. Another student used a shared login.', desc: 'Someone used my lab login while I was away and changed my files.' },
  { user: 'faculty', title: 'Unknown Wi-Fi hotspot imitating college network', type: 'Other', severity: 'Low', status: 'Resolved', days: 6, time: '08:50:00', location: 'Main Block Wi-Fi', assigned: 'sec1', resolution: 'Rogue hotspot located and removed. Notice sent to students about verifying the official network name.', desc: 'A Wi-Fi network with a name very similar to the college network appeared near the main block.' },
  { user: 'faculty', title: 'Faculty email account compromised', type: 'Account Compromise', severity: 'Critical', status: 'Closed', days: 8, time: '07:30:00', location: 'College Email', assigned: 'sec2', resolution: 'Password reset, active sessions revoked, two-step verification enabled. No data loss found.', note: 'Spam emails were sent from the account. Credentials reset and sessions revoked.', desc: 'My students reported receiving strange emails from my college address that I did not send.' },
];

async function seed() {
  const conn = await pool.getConnection();
  try {
    await conn.query('SET FOREIGN_KEY_CHECKS = 0');
    for (const table of ['incident_history', 'incident_notes', 'incidents', 'users']) {
      await conn.query(`TRUNCATE TABLE ${table}`);
    }
    await conn.query('SET FOREIGN_KEY_CHECKS = 1');

    const ids = {};
    for (const u of USERS) {
      const hash = await bcrypt.hash(u.password, 10);
      const [r] = await conn.query(
        'INSERT INTO users (name, email, password, role, department) VALUES (?, ?, ?, ?, ?)',
        [u.name, u.email, hash, u.role, u.department]
      );
      ids[u.key] = r.insertId;
    }

    const year = new Date().getFullYear();
    let counter = 0;
    for (const s of INCIDENTS) {
      counter += 1;
      const incidentId = `INC-${year}-${String(counter).padStart(4, '0')}`;
      const assignedTo = s.assigned ? ids[s.assigned] : null;
      const [r] = await conn.query(
        `INSERT INTO incidents
           (incident_id, user_id, title, type, description, severity, status, incident_date, incident_time, location, assigned_to, resolution, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE() - INTERVAL ? DAY, ?, ?, ?, ?, NOW() - INTERVAL ? DAY)`,
        [incidentId, ids[s.user], s.title, s.type, s.desc, s.severity, s.status, s.days, s.time, s.location, assignedTo, s.resolution || null, s.days]
      );

      await conn.query(
        'INSERT INTO incident_history (incident_id, user_id, action, old_value, new_value) VALUES (?, ?, ?, ?, ?)',
        [r.insertId, ids[s.user], 'Incident reported', null, 'New']
      );
      if (s.status !== 'New') {
        await conn.query(
          'INSERT INTO incident_history (incident_id, user_id, action, old_value, new_value) VALUES (?, ?, ?, ?, ?)',
          [r.insertId, ids.admin, 'Status changed', 'New', s.status]
        );
      }
      if (s.note) {
        await conn.query('INSERT INTO incident_notes (incident_id, admin_id, note) VALUES (?, ?, ?)', [r.insertId, assignedTo || ids.admin, s.note]);
      }
    }

    console.log('Seed completed successfully.\n');
    console.log('Demo accounts:');
    for (const u of USERS) console.log(`  ${u.role.padEnd(9)} ${u.email.padEnd(24)} password: ${u.password}`);
    console.log(`\n${INCIDENTS.length} sample incidents created.`);
  } finally {
    conn.release();
    await pool.end();
  }
}

seed().catch((err) => {
  console.error('Seed failed:', err.code || err.message);
  console.error('Make sure MySQL is running, backend/.env is configured and database/schema.sql has been executed.');
  process.exit(1);
});
