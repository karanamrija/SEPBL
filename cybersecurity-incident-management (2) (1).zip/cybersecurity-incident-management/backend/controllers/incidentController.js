const fs = require('fs');
const path = require('path');
const Incident = require('../models/incidentModel');
const User = require('../models/userModel');
const { HttpError } = require('../middleware/errorHandler');

const isAdmin = (user) => user.role === 'admin' || user.role === 'security';
const str = (v) => (typeof v === 'string' ? v.trim() : '');

async function findOr404(param) {
  let incident;
  if (/^\d+$/.test(param)) incident = await Incident.findById(Number(param));
  else if (/^INC-\d{4}-\d{4}$/i.test(param)) incident = await Incident.findByIncidentId(param.toUpperCase());
  else throw new HttpError(400, 'Invalid incident ID.');
  if (!incident) throw new HttpError(404, 'Incident not found.');
  return incident;
}

function assertAccess(incident, user) {
  if (!isAdmin(user) && incident.user_id !== user.id) {
    throw new HttpError(403, 'You can only view your own incidents.');
  }
}

function removeUpload(file) {
  if (file) fs.unlink(file.path, () => {});
}

function validateCreate(body) {
  const v = {
    title: str(body.title),
    type: str(body.type),
    description: str(body.description),
    severity: str(body.severity) || 'Medium',
    incident_date: str(body.incident_date),
    incident_time: str(body.incident_time),
    location: str(body.location),
  };
  const errors = [];
  if (v.title.length < 3 || v.title.length > 150) errors.push('Title must be 3-150 characters.');
  if (!Incident.TYPES.includes(v.type)) errors.push('Please select a valid incident type.');
  if (v.description.length < 10) errors.push('Description must be at least 10 characters.');
  if (!Incident.SEVERITIES.includes(v.severity)) errors.push('Please select a valid severity.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v.incident_date) || isNaN(Date.parse(v.incident_date))) errors.push('A valid incident date is required.');
  if (!/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(v.incident_time)) errors.push('A valid incident time is required.');
  else if (v.incident_time.length === 5) v.incident_time += ':00';
  if (!v.location || v.location.length > 150) errors.push('Location / system affected is required (max 150 characters).');
  return { v, errors };
}

exports.createIncident = async (req, res) => {
  const { v, errors } = validateCreate(req.body);
  if (errors.length) {
    removeUpload(req.file);
    throw new HttpError(400, 'Please fix the following:', errors);
  }
  v.user_id = req.user.id;
  v.evidence = req.file ? req.file.filename : null;
  const incident = await Incident.create(v);
  res.status(201).json({ message: 'Incident reported successfully.', incident });
};

exports.listIncidents = async (req, res) => {
  const filters = {
    type: str(req.query.type),
    severity: str(req.query.severity),
    status: str(req.query.status),
    date: str(req.query.date),
    search: str(req.query.search),
  };
  const opts = isAdmin(req.user) ? {} : { userId: req.user.id };
  const incidents = await Incident.list(filters, opts);
  res.json({ incidents });
};

exports.getIncident = async (req, res) => {
  const incident = await findOr404(req.params.id);
  assertAccess(incident, req.user);
  const notes = isAdmin(req.user) ? await Incident.getNotes(incident.id) : []; // notes are internal
  const history = await Incident.getHistory(incident.id);
  res.json({ incident, notes, history });
};

// Admin: update severity / type / resolution text
exports.updateIncident = async (req, res) => {
  const incident = await findOr404(req.params.id);
  const changes = {};
  const errors = [];

  if (req.body.severity !== undefined) {
    if (!Incident.SEVERITIES.includes(req.body.severity)) errors.push('Invalid severity.');
    else changes.severity = req.body.severity;
  }
  if (req.body.type !== undefined) {
    if (!Incident.TYPES.includes(req.body.type)) errors.push('Invalid incident type.');
    else changes.type = req.body.type;
  }
  if (req.body.resolution !== undefined) changes.resolution = str(req.body.resolution) || null;

  if (errors.length) throw new HttpError(400, 'Validation failed.', errors);
  if (!Object.keys(changes).length) throw new HttpError(400, 'No valid fields to update.');

  await Incident.update(incident.id, changes);
  if (changes.severity && changes.severity !== incident.severity) {
    await Incident.addHistory(incident.id, req.user.id, 'Severity changed', incident.severity, changes.severity);
  }
  if (changes.type && changes.type !== incident.type) {
    await Incident.addHistory(incident.id, req.user.id, 'Type changed', incident.type, changes.type);
  }
  res.json({ message: 'Incident updated successfully.', incident: await Incident.findById(incident.id) });
};

exports.updateStatus = async (req, res) => {
  const incident = await findOr404(req.params.id);
  const status = str(req.body.status);

  if (!Incident.STATUSES.includes(status)) throw new HttpError(400, 'Invalid status value.');
  if (status === incident.status) throw new HttpError(400, `Incident is already "${status}".`);

  const allowed = Incident.TRANSITIONS[incident.status];
  if (!allowed.includes(status)) {
    throw new HttpError(
      400,
      `Invalid status change: ${incident.status} → ${status}. ` +
        (allowed.length ? `Allowed next: ${allowed.join(', ')}.` : 'This incident is closed.')
    );
  }
  if (status !== 'Assigned' && !incident.assigned_to) {
    throw new HttpError(400, 'Assign the incident to a staff member first.');
  }

  const changes = { status };
  if (status === 'Resolved') {
    const resolution = str(req.body.resolution) || incident.resolution;
    if (!resolution) throw new HttpError(400, 'Resolution details are required to resolve an incident.');
    changes.resolution = resolution;
  }

  await Incident.update(incident.id, changes);
  await Incident.addHistory(incident.id, req.user.id, 'Status changed', incident.status, status);
  res.json({ message: `Status updated to ${status}.`, incident: await Incident.findById(incident.id) });
};

exports.assignIncident = async (req, res) => {
  const incident = await findOr404(req.params.id);
  const staffId = Number(req.body.assigned_to);

  if (!Number.isInteger(staffId) || staffId <= 0) throw new HttpError(400, 'A valid staff member is required.');
  if (incident.status === 'Closed') throw new HttpError(400, 'A closed incident cannot be reassigned.');

  const staff = await User.findStaffById(staffId);
  if (!staff) throw new HttpError(404, 'Selected staff member not found.');

  const changes = { assigned_to: staffId };
  if (incident.status === 'New') changes.status = 'Assigned';

  await Incident.update(incident.id, changes);
  await Incident.addHistory(incident.id, req.user.id, 'Assigned to', incident.assigned_name, staff.name);
  if (changes.status) {
    await Incident.addHistory(incident.id, req.user.id, 'Status changed', 'New', 'Assigned');
  }
  res.json({ message: `Incident assigned to ${staff.name}.`, incident: await Incident.findById(incident.id) });
};

exports.addNote = async (req, res) => {
  const incident = await findOr404(req.params.id);
  const note = str(req.body.note);
  if (note.length < 3 || note.length > 2000) throw new HttpError(400, 'Note must be 3-2000 characters.');
  const saved = await Incident.addNote(incident.id, req.user.id, note);
  res.status(201).json({ message: 'Investigation note added.', note: saved });
};

exports.deleteIncident = async (req, res) => {
  const incident = await findOr404(req.params.id);
  if (incident.evidence) {
    fs.unlink(path.join(__dirname, '..', 'uploads', incident.evidence), () => {});
  }
  await Incident.remove(incident.id);
  res.json({ message: 'Incident deleted successfully.' });
};
