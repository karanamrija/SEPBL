const { pool } = require('../config/db');
const Incident = require('../models/incidentModel');

const isAdmin = (user) => user.role === 'admin' || user.role === 'security';

exports.getStats = async (req, res) => {
  const admin = isAdmin(req.user);
  const where = admin ? '' : 'WHERE user_id = ?';
  const params = admin ? [] : [req.user.id];

  const [[t]] = await pool.query(
    `SELECT COUNT(*) AS total,
            SUM(status = 'New') AS new_count,
            SUM(status = 'Assigned') AS assigned,
            SUM(status = 'Under Investigation') AS investigating,
            SUM(status = 'Resolved') AS resolved,
            SUM(status = 'Closed') AS closed,
            SUM(severity = 'Critical') AS critical
     FROM incidents ${where}`,
    params
  );

  const group = async (column) => {
    const [rows] = await pool.query(
      `SELECT ${column} AS label, COUNT(*) AS cnt FROM incidents ${where} GROUP BY ${column} ORDER BY cnt DESC`,
      params
    );
    return rows.map((r) => ({ label: r.label, count: Number(r.cnt) }));
  };

  const recent = await Incident.list({}, { userId: admin ? null : req.user.id, limit: 5 });

  res.json({
    totals: {
      total: Number(t.total || 0),
      new: Number(t.new_count || 0),
      assigned: Number(t.assigned || 0),
      underInvestigation: Number(t.investigating || 0),
      resolved: Number(t.resolved || 0),
      closed: Number(t.closed || 0),
      critical: Number(t.critical || 0),
    },
    byType: await group('type'),
    bySeverity: await group('severity'),
    byStatus: await group('status'),
    recent,
  });
};
