const bcrypt = require('bcryptjs');
const User = require('../models/userModel');
const { HttpError } = require('../middleware/errorHandler');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ROLES = ['user', 'admin', 'security'];

exports.listUsers = async (req, res) => {
  res.json({ users: await User.listAll() });
};

exports.listStaff = async (req, res) => {
  res.json({ users: await User.listStaff() });
};

exports.createUser = async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const role = String(req.body.role || 'user');
  const department = String(req.body.department || '').trim();

  const errors = [];
  if (name.length < 2 || name.length > 100) errors.push('Name must be 2-100 characters.');
  if (!EMAIL_RE.test(email)) errors.push('A valid email is required.');
  if (password.length < 6) errors.push('Password must be at least 6 characters.');
  if (!ROLES.includes(role)) errors.push('Invalid role.');
  if (department.length > 100) errors.push('Department is too long.');
  if (errors.length) throw new HttpError(400, 'Validation failed.', errors);

  if (await User.findByEmail(email)) throw new HttpError(409, 'A user with this email already exists.');

  const hash = await bcrypt.hash(password, 10);
  const user = await User.create({ name, email, password: hash, role, department });
  res.status(201).json({ message: 'User created successfully.', user });
};
