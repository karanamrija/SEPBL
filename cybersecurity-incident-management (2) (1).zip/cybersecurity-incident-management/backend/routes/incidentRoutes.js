const router = require('express').Router();
const asyncHandler = require('../middleware/asyncHandler');
const { authenticate, authorize, ADMIN_ROLES } = require('../middleware/auth');
const upload = require('../middleware/upload');
const ctrl = require('../controllers/incidentController');

router.use(authenticate);

router.get('/', asyncHandler(ctrl.listIncidents));
router.post('/', upload.single('evidence'), asyncHandler(ctrl.createIncident));
router.get('/:id', asyncHandler(ctrl.getIncident));

router.put('/:id', authorize(...ADMIN_ROLES), asyncHandler(ctrl.updateIncident));
router.put('/:id/status', authorize(...ADMIN_ROLES), asyncHandler(ctrl.updateStatus));
router.put('/:id/assign', authorize(...ADMIN_ROLES), asyncHandler(ctrl.assignIncident));
router.post('/:id/notes', authorize(...ADMIN_ROLES), asyncHandler(ctrl.addNote));
router.delete('/:id', authorize('admin'), asyncHandler(ctrl.deleteIncident));

module.exports = router;
