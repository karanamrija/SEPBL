const router = require('express').Router();
const asyncHandler = require('../middleware/asyncHandler');
const { authenticate } = require('../middleware/auth');
const ctrl = require('../controllers/authController');

router.post('/login', asyncHandler(ctrl.login));
router.get('/me', authenticate, asyncHandler(ctrl.me));

module.exports = router;
