const router = require('express').Router();
const asyncHandler = require('../middleware/asyncHandler');
const { authenticate } = require('../middleware/auth');
const ctrl = require('../controllers/dashboardController');

router.get('/stats', authenticate, asyncHandler(ctrl.getStats));

module.exports = router;
