const router = require('express').Router();
const asyncHandler = require('../middleware/asyncHandler');
const { authenticate, authorize, ADMIN_ROLES } = require('../middleware/auth');
const ctrl = require('../controllers/userController');

router.use(authenticate);

router.get('/staff', authorize(...ADMIN_ROLES), asyncHandler(ctrl.listStaff));
router.get('/', authorize('admin'), asyncHandler(ctrl.listUsers));
router.post('/', authorize('admin'), asyncHandler(ctrl.createUser));

module.exports = router;
