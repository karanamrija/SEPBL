const { pool } = require('../config/db');

const PUBLIC_COLUMNS = 'id, name, email, role, department, created_at';

async function findByEmail(email) {
  const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
  return rows[0];
}

async function findById(id) {
  const [rows] = await pool.query(`SELECT ${PUBLIC_COLUMNS} FROM users WHERE id = ?`, [id]);
  return rows[0];
}

async function findStaffById(id) {
  const [rows] = await pool.query(
    `SELECT ${PUBLIC_COLUMNS} FROM users WHERE id = ? AND role IN ('admin', 'security')`,
    [id]
  );
  return rows[0];
}

async function listAll() {
  const [rows] = await pool.query(`SELECT ${PUBLIC_COLUMNS} FROM users ORDER BY created_at DESC, id DESC`);
  return rows;
}

async function listStaff() {
  const [rows] = await pool.query(
    `SELECT ${PUBLIC_COLUMNS} FROM users WHERE role IN ('admin', 'security') ORDER BY name`
  );
  return rows;
}

async function create({ name, email, password, role, department }) {
  const [result] = await pool.query(
    'INSERT INTO users (name, email, password, role, department) VALUES (?, ?, ?, ?, ?)',
    [name, email, password, role, department || null]
  );
  return findById(result.insertId);
}

module.exports = { findByEmail, findById, findStaffById, listAll, listStaff, create };
