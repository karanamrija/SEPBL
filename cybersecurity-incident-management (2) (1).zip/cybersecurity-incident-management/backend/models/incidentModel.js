const { pool } = require('../config/db');

const TYPES = [
  'Phishing',
  'Malware',
  'Unauthorized Access',
  'Suspicious Login',
  'Data Leakage',
  'Account Compromise',
  'Ransomware',
  'Other',
];
const SEVERITIES = ['Low', 'Medium', 'High', 'Critical'];
const STATUSES = ['New', 'Assigned', 'Under Investigation', 'Resolved', 'Closed'];

// Allowed lifecycle transitions
const TRANSITIONS = {
  New: ['Assigned'],
  Assigned: ['Under Investigation'],
  'Under Investigation': ['Resolved'],
  Resolved: ['Closed', 'Under Investigation'],
  Closed: [],
};

const BASE_SELECT = `
  SELECT i.*,
         u.name AS reporter_name, u.email AS reporter_email, u.department AS reporter_department,
         a.name AS assigned_name
  FROM incidents i
  JOIN users u ON u.id = i.user_id
  LEFT JOIN users a ON a.id = i.assigned_to`;

async function findById(id) {
  const [rows] = await pool.query(`${BASE_SELECT} WHERE i.id = ?`, [id]);
  return rows[0];
}

async function findByIncidentId(incidentId) {
  const [rows] = await pool.query(`${BASE_SELECT} WHERE i.incident_id = ?`, [incidentId]);
  return rows[0];
}

async function list(filters = {}, opts = {}) {
  const where = [];
  const params = [];
  if (opts.userId) {
    where.push('i.user_id = ?');
    params.push(opts.userId);
  }
  if (filters.type) { where.push('i.type = ?'); params.push(filters.type); }
  if (filters.severity) { where.push('i.severity = ?'); params.push(filters.severity); }
  if (filters.status) { where.push('i.status = ?'); params.push(filters.status); }
  if (filters.date) { where.push('i.incident_date = ?'); params.push(filters.date); }
  if (filters.search) {
    const s = `%${filters.search}%`;
    where.push('(i.title LIKE ? OR i.incident_id LIKE ? OR i.description LIKE ? OR u.name LIKE ?)');
    params.push(s, s, s, s);
  }
  let sql = BASE_SELECT;
  if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
  sql += ' ORDER BY i.created_at DESC, i.id DESC';
  if (opts.limit) {
    sql += ' LIMIT ?';
    params.push(Number(opts.limit));
  }
  const [rows] = await pool.query(sql, params);
  return rows;
}

async function nextIncidentId() {
  const prefix = `INC-${new Date().getFullYear()}-`;
  const [rows] = await pool.query(
    'SELECT incident_id FROM incidents WHERE incident_id LIKE ? ORDER BY incident_id DESC LIMIT 1',
    [`${prefix}%`]
  );
  const last = rows.length ? parseInt(rows[0].incident_id.slice(prefix.length), 10) : 0;
  return prefix + String(last + 1).padStart(4, '0');
}

async function addHistory(incidentDbId, userId, action, oldValue, newValue) {
  await pool.query(
    'INSERT INTO incident_history (incident_id, user_id, action, old_value, new_value) VALUES (?, ?, ?, ?, ?)',
    [incidentDbId, userId, action, oldValue || null, newValue || null]
  );
}

async function create(v) {
  for (let attempt = 0; attempt < 5; attempt++) {
    const incidentId = await nextIncidentId();
    try {
      const [result] = await pool.query(
        `INSERT INTO incidents
           (incident_id, user_id, title, type, description, severity, status, incident_date, incident_time, location, evidence)
         VALUES (?, ?, ?, ?, ?, ?, 'New', ?, ?, ?, ?)`,
        [incidentId, v.user_id, v.title, v.type, v.description, v.severity, v.incident_date, v.incident_time, v.location, v.evidence]
      );
      await addHistory(result.insertId, v.user_id, 'Incident reported', null, 'New');
      return findById(result.insertId);
    } catch (err) {
      if (err.code !== 'ER_DUP_ENTRY') throw err; // retry only on duplicate ID
    }
  }
  throw new Error('Could not generate a unique incident ID.');
}

const UPDATABLE = ['type', 'severity', 'status', 'assigned_to', 'resolution'];

async function update(id, columns) {
  const keys = Object.keys(columns).filter((k) => UPDATABLE.includes(k));
  if (!keys.length) return;
  const sql = `UPDATE incidents SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`;
  await pool.query(sql, [...keys.map((k) => columns[k]), id]);
}

async function remove(id) {
  await pool.query('DELETE FROM incidents WHERE id = ?', [id]);
}

async function addNote(incidentDbId, adminId, note) {
  const [result] = await pool.query(
    'INSERT INTO incident_notes (incident_id, admin_id, note) VALUES (?, ?, ?)',
    [incidentDbId, adminId, note]
  );
  const [rows] = await pool.query(
    `SELECT n.*, u.name AS admin_name FROM incident_notes n JOIN users u ON u.id = n.admin_id WHERE n.id = ?`,
    [result.insertId]
  );
  return rows[0];
}

async function getNotes(incidentDbId) {
  const [rows] = await pool.query(
    `SELECT n.*, u.name AS admin_name FROM incident_notes n JOIN users u ON u.id = n.admin_id
     WHERE n.incident_id = ? ORDER BY n.created_at DESC, n.id DESC`,
    [incidentDbId]
  );
  return rows;
}

async function getHistory(incidentDbId) {
  const [rows] = await pool.query(
    `SELECT h.*, u.name AS user_name FROM incident_history h JOIN users u ON u.id = h.user_id
     WHERE h.incident_id = ? ORDER BY h.created_at DESC, h.id DESC`,
    [incidentDbId]
  );
  return rows;
}

module.exports = {
  TYPES, SEVERITIES, STATUSES, TRANSITIONS,
  findById, findByIncidentId, list, create, update, remove,
  addNote, getNotes, getHistory, addHistory,
};
