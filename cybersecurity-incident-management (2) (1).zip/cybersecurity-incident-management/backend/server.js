require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const { testConnection } = require('./config/db');
const { notFound, errorHandler } = require('./middleware/errorHandler');

if (!process.env.JWT_SECRET) {
  console.error('ERROR: JWT_SECRET is missing. Create backend/.env (copy from .env.example).');
  process.exit(1);
}

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: true }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/incidents', require('./routes/incidentRoutes'));
app.use('/api/dashboard', require('./routes/dashboardRoutes'));
app.use('/api/users', require('./routes/userRoutes'));

app.use(notFound);
app.use(errorHandler);

testConnection()
  .then(() => {
    console.log('MySQL connected successfully.');
    app.listen(PORT, () => console.log(`Backend running at http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('ERROR: Could not connect to MySQL.');
    console.error('Reason:', err.code || err.message);
    console.error('Check DB_HOST, DB_USER, DB_PASSWORD and DB_NAME in backend/.env, and that MySQL is running and schema.sql has been executed.');
    process.exit(1);
  });
