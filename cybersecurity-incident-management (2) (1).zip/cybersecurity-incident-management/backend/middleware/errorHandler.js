const multer = require('multer');

class HttpError extends Error {
  constructor(status, message, errors) {
    super(message);
    this.status = status;
    this.errors = errors;
  }
}

function notFound(req, res) {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof multer.MulterError) {
    const message =
      err.code === 'LIMIT_FILE_SIZE' ? 'File too large. Maximum allowed size is 5 MB.' : `File upload error: ${err.message}`;
    return res.status(400).json({ message });
  }
  if (err.message === 'INVALID_FILE_TYPE') {
    return res.status(400).json({ message: 'Invalid file type. Allowed: PNG, JPG, GIF, PDF, TXT, DOC, DOCX.' });
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Invalid JSON in request body.' });
  }
  if (err.status) {
    return res.status(err.status).json({ message: err.message, errors: err.errors });
  }
  if ((err.code && String(err.code).startsWith('ER_')) || err.code === 'ECONNREFUSED') {
    console.error('Database error:', err.code, err.message);
    return res.status(500).json({ message: 'Database error. Please try again later.' });
  }
  console.error(err);
  return res.status(500).json({ message: 'Internal server error.' });
}

module.exports = { HttpError, notFound, errorHandler };
