require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'cyber_incident_management',
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true, // return DATE/TIME/TIMESTAMP as plain strings (avoids timezone shifts)
});

async function testConnection() {
  const conn = await pool.getConnection();
  conn.release();
}

module.exports = { pool, testConnection };
