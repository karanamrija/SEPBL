// Creates the database and tables by running ../database/schema.sql
// Run with:  node setup-db.js     (WARNING: deletes existing data in these tables)
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

(async () => {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });
  const sql = fs.readFileSync(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8');
  await conn.query(sql);
  console.log('Database and tables created successfully.');
  await conn.end();
})().catch((e) => {
  console.error('Failed:', e.code || e.message);
  process.exit(1);
});
