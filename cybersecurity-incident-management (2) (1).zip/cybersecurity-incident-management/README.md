# CyberShield — Cybersecurity Incident Management System for Colleges

A centralized web portal where students and staff report cybersecurity incidents (phishing, malware, unauthorized access, etc.) and the college security team classifies, assigns, investigates and resolves them.

## Problem statement
Incidents are currently reported by email, phone, WhatsApp or verbally, so the IT/security team cannot centrally record, classify, assign, track and resolve them. This system provides one platform for the full incident lifecycle:

`Report → Incident ID → Admin review → Classify → Assign → Investigate → Status updates → Resolve → Close → History/report`

## Features
- JWT login with bcrypt-hashed passwords; role-based access (Student/Staff, Security Staff, Admin)
- Report incident with evidence upload (PNG/JPG/GIF/PDF/TXT/DOC/DOCX, max 5 MB); auto ID `INC-YYYY-NNNN`
- User dashboard, My Incidents (search + filters), incident details with lifecycle tracker
- Admin dashboard: 6 stat cards, charts by type/severity/status, recent incidents
- Admin: search, filter (type/severity/status/date), change severity, assign staff, change status, investigation notes, resolution details, close, delete (admin only), manage users
- Full incident history (audit trail)

## Technology stack
React 18 + Vite + React Router + Axios | Node.js + Express | MySQL (mysql2) | JWT, bcryptjs, multer, dotenv

## Architecture (3-tier)
`React (Presentation, :5173)  →  Express REST API (Application, :5000)  →  MySQL (Database, :3306)`
Vite proxies `/api` and `/uploads` to the backend, so there are no CORS problems in development.

## Folder structure
```
cybersecurity-incident-management/
├── README.md
├── docs/
│   ├── SOFTWARE_ENGINEERING_MAPPING.md  (PBL sections 1-15, requirements, SRS outline)
│   ├── PBL_DOCUMENTATION.md             (diagram details + 22 test cases)
│   └── diagrams/                        (8 UML/DFD/architecture diagrams: PNG + SVG + sources)
├── database/schema.sql
├── backend/  (server.js, seed.js, config/, middleware/, models/, controllers/, routes/, uploads/)
└── frontend/ (index.html, vite.config.js, src/{components,pages,context,services,hooks,utils})
```

## Installation (Windows + VS Code)
Prerequisites: Node.js (LTS), MySQL Server (remember your root password), VS Code.

1. Unzip the project and open the folder in VS Code (**File → Open Folder**). Open a terminal with **Ctrl + `**.

2. **Configure the backend** (steps 2-3 below), then create the database with `node setup-db.js` (no `mysql` command needed).
3. **Configure the backend**
   ```
   cd backend
   copy .env.example .env
   ```
   Open `backend/.env` and set `DB_PASSWORD=` to your MySQL root password.
4. **Install, create the database and demo data, and start the backend**
   ```
   npm install
   node setup-db.js
   npm run seed
   npm run dev
   ```
   You should see `MySQL connected successfully.` and `Backend running at http://localhost:5000`.
5. **Start the frontend** (open a second terminal with the **+** icon)
   ```
   cd frontend
   npm install
   npm run dev
   ```
6. Open **http://localhost:5173** in your browser.

## Demo accounts (created by `npm run seed` in `backend/seed.js`)
| Role | Email | Password |
|---|---|---|
| Admin | admin@college.com | admin123 |
| Student | student@college.com | student123 |
| Security staff | security1@college.com / security2@college.com | security123 |
| Student | sneha@college.com | student123 |
| Faculty | faculty@college.com | faculty123 |

The seed also creates 9 sample incidents. Re-run `npm run seed` any time to reset the data.

## Environment variables (`backend/.env`)
`PORT`, `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, `JWT_SECRET`, `JWT_EXPIRES_IN`

## Demonstration flow
1. Open http://localhost:5173 → click **Student** demo button → **Sign In**.
2. Dashboard → **Report New Incident** → choose type *Phishing*, fill title/description/location → **Submit Report**.
3. Note the Incident ID shown (e.g. `INC-2026-0010`) → **Logout**.
4. Login as **Admin** → admin dashboard shows the new incident in *Recent Incidents* and *New Incidents* = +1.
5. Open the incident → set **Severity = High** → **Update**.
6. **Assign** to *Ravi Kumar* (status becomes *Assigned* automatically).
7. **Change Status** → *Under Investigation*.
8. Add an **Investigation Note**.
9. **Change Status** → *Resolved*, type the **resolution details** → **Resolve Incident**.
10. **Change Status** → *Closed* → **Close Incident**.
11. Go back to **Dashboard** → statistics are updated.

## API overview (all under `/api`, JWT `Authorization: Bearer <token>` except login)
| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | /auth/login | public | Login, returns token + user |
| GET | /auth/me | any | Current user profile |
| POST | /incidents | any | Report incident (multipart/form-data, field `evidence`) |
| GET | /incidents | any | List (users: own; admin: all). Query: `type,severity,status,date,search` |
| GET | /incidents/:id | owner/admin | Details + notes (admin) + history. `:id` = number or `INC-2026-0001` |
| PUT | /incidents/:id | admin/security | Update severity / type / resolution |
| PUT | /incidents/:id/status | admin/security | Change status (`status`, `resolution`) — lifecycle enforced |
| PUT | /incidents/:id/assign | admin/security | Assign staff (`assigned_to`) |
| POST | /incidents/:id/notes | admin/security | Add investigation note (`note`) |
| DELETE | /incidents/:id | admin | Delete incident |
| GET | /dashboard/stats | any | Statistics (users: own; admin: all) |
| GET | /users | admin | List users |
| GET | /users/staff | admin/security | Staff list for assignment |
| POST | /users | admin | Create user |

Status codes used: 200, 201, 400 (validation), 401 (not logged in / bad login), 403 (forbidden), 404 (not found), 409 (duplicate email), 500.

## Status lifecycle
`New → Assigned → Under Investigation → Resolved → Closed` (a Resolved incident may be re-opened to Under Investigation).

## Security practices
bcrypt password hashing, JWT authentication, role-based authorization on every route, input validation, parameterized SQL queries (no SQL injection), file-type and size restrictions on uploads, secrets in `.env` (not in source code).

## Diagrams (Software Engineering PBL)
Inside the app: click **Diagrams** in the sidebar (or **View Project Diagrams** on the login page) and click any of the 8 diagrams to view it.

Open `docs/diagrams/index.html` in a browser to see all 8 diagrams: Use Case, Class, Activity, Sequence, Component, Deployment, DFD (level 0 and 1) and Software Architecture. PNG and SVG files and editable sources are in the same folder (see `docs/diagrams/HOW_TO_EDIT.md`).

## Testing
See `docs/PBL_DOCUMENTATION.md` for 22 test cases, and `docs/SOFTWARE_ENGINEERING_MAPPING.md` for how every PBL section maps to this project.

## Troubleshooting
| Problem | Solution |
|---|---|
| `npm` is not recognized | Install Node.js LTS from nodejs.org, then close and reopen VS Code. |
| `'mysql' is not recognized` | Not needed. Use `node setup-db.js` instead. |
| `ECONNREFUSED` / MySQL connection refused | Start MySQL: Windows **Services → MySQL80 → Start**. Check `DB_HOST`, `DB_PORT` in `.env`. |
| `ER_ACCESS_DENIED_ERROR` | Wrong `DB_USER` / `DB_PASSWORD` in `backend/.env`. |
| `ER_BAD_DB_ERROR` / Unknown database | Run `node setup-db.js` in the backend folder first. |
| `Table ... doesn't exist` | Run `node setup-db.js`, then `npm run seed`. |
| Port 5000 / 5173 already in use | Change `PORT` in `.env` (and the proxy target in `frontend/vite.config.js`), or stop the other program. |
| "Cannot reach the server" in browser | Backend is not running — run `npm run dev` in `backend`. |
| CORS error | Open the app at http://localhost:5173 (not by double-clicking files). Backend CORS is enabled. |
| `Cannot find module ...` | Run `npm install` inside the folder showing the error. |
| Login not working | Run `npm run seed` again; use the exact demo credentials; check the backend terminal for errors. |
| `JWT_SECRET is missing` | You did not create `backend/.env` (copy `.env.example`). |
| Changes to `.env` ignored | Restart the backend (Ctrl+C, then `npm run dev`). |

## Future enhancements
Email/SMS notifications, SLA timers, PDF/Excel incident reports, two-factor login, password reset, incident attachments preview, charts over time, audit-log export.
