-- =====================================================
-- Cybersecurity Incident Management System for Colleges
-- Database schema (MySQL 8.x / 5.7+)
-- WARNING: re-running this file deletes existing data.
-- =====================================================

CREATE DATABASE IF NOT EXISTS cyber_incident_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE cyber_incident_management;

DROP TABLE IF EXISTS incident_history;
DROP TABLE IF EXISTS incident_notes;
DROP TABLE IF EXISTS incidents;
DROP TABLE IF EXISTS users;

-- ---------- users ----------
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,                       -- bcrypt hash
  role ENUM('user', 'admin', 'security') NOT NULL DEFAULT 'user',
  department VARCHAR(100) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- incidents ----------
CREATE TABLE incidents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id VARCHAR(20) NOT NULL UNIQUE,              -- e.g. INC-2026-0001
  user_id INT NOT NULL,                                 -- reporter
  title VARCHAR(150) NOT NULL,
  type ENUM('Phishing', 'Malware', 'Unauthorized Access', 'Suspicious Login',
            'Data Leakage', 'Account Compromise', 'Ransomware', 'Other') NOT NULL,
  description TEXT NOT NULL,
  severity ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL DEFAULT 'Medium',
  status ENUM('New', 'Assigned', 'Under Investigation', 'Resolved', 'Closed') NOT NULL DEFAULT 'New',
  incident_date DATE NOT NULL,
  incident_time TIME NOT NULL,
  location VARCHAR(150) NOT NULL,
  evidence VARCHAR(255) NULL,                           -- uploaded file name
  assigned_to INT NULL,                                 -- security staff
  resolution TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_incident_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_incident_assigned FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_incident_status (status),
  INDEX idx_incident_severity (severity),
  INDEX idx_incident_type (type),
  INDEX idx_incident_user (user_id)
) ENGINE=InnoDB;

-- ---------- incident_notes (investigation notes) ----------
CREATE TABLE incident_notes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT NOT NULL,
  admin_id INT NOT NULL,
  note TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_note_incident FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE,
  CONSTRAINT fk_note_admin FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------- incident_history (audit trail) ----------
CREATE TABLE incident_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  incident_id INT NOT NULL,
  user_id INT NOT NULL,
  action VARCHAR(100) NOT NULL,
  old_value VARCHAR(255) NULL,
  new_value VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_history_incident FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE,
  CONSTRAINT fk_history_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- NOTE: Demo users and sample incidents are NOT inserted here because passwords
-- must be bcrypt-hashed. They are created by:  cd backend && npm run seed
