export const INCIDENT_TYPES = [
  'Phishing',
  'Malware',
  'Unauthorized Access',
  'Suspicious Login',
  'Data Leakage',
  'Account Compromise',
  'Ransomware',
  'Other',
];

export const SEVERITIES = ['Low', 'Medium', 'High', 'Critical'];

// Lifecycle order
export const STATUSES = ['New', 'Assigned', 'Under Investigation', 'Resolved', 'Closed'];

// Allowed next statuses (must match backend/models/incidentModel.js)
export const TRANSITIONS = {
  New: ['Assigned'],
  Assigned: ['Under Investigation'],
  'Under Investigation': ['Resolved'],
  Resolved: ['Closed', 'Under Investigation'],
  Closed: [],
};

export const EMPTY_FILTERS = { search: '', type: '', severity: '', status: '', date: '' };

export const isAdminRole = (role) => role === 'admin' || role === 'security';

export const ROLE_LABELS = {
  user: 'Student / Staff',
  security: 'Security Staff',
  admin: 'Security Administrator',
};
