import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../services/api';

export default function useIncidentList(filters) {
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const timer = setTimeout(async () => {
      try {
        setLoading(true);
        const { data } = await api.get('/incidents', { params: filters });
        setIncidents(data.incidents);
        setError('');
      } catch (err) {
        setError(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [filters]);

  return { incidents, loading, error };
}
