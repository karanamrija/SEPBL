import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { getErrorMessage } from '../services/api';
import StatCard from '../components/StatCard';
import BarList from '../components/BarList';
import IncidentTable from '../components/IncidentTable';

const q = (key, value) => `/admin/incidents?${key}=${encodeURIComponent(value)}`;

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/dashboard/stats')
      .then((r) => setStats(r.data))
      .catch((e) => setError(getErrorMessage(e)));
  }, []);

  return (
    <>
      <div className="page-header">
        <div>
          <h2>Security Operations Dashboard</h2>
          <p className="muted">Overview of all cybersecurity incidents reported across the college.</p>
        </div>
        <Link to="/admin/incidents" className="btn btn-primary">Manage Incidents</Link>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {stats && (
        <>
          <div className="stats-grid six">
            <StatCard label="Total Incidents" value={stats.totals.total} icon="📋" color="blue" to="/admin/incidents" />
            <StatCard label="New Incidents" value={stats.totals.new} icon="🆕" color="cyan" to={q('status', 'New')} />
            <StatCard label="Assigned" value={stats.totals.assigned} icon="👤" color="purple" to={q('status', 'Assigned')} />
            <StatCard label="Under Investigation" value={stats.totals.underInvestigation} icon="🔍" color="orange" to={q('status', 'Under Investigation')} />
            <StatCard label="Resolved" value={stats.totals.resolved} icon="✅" color="green" to={q('status', 'Resolved')} />
            <StatCard label="Critical" value={stats.totals.critical} icon="🔥" color="red" to={q('severity', 'Critical')} />
          </div>

          <div className="grid-3">
            <BarList title="Incidents by Type" data={stats.byType} />
            <BarList title="Incidents by Severity" data={stats.bySeverity} />
            <BarList title="Incidents by Status" data={stats.byStatus} />
          </div>

          <div className="card">
            <div className="card-head">
              <h3 className="card-title">Recent Incidents</h3>
              <Link to="/admin/incidents">Search &amp; filter all →</Link>
            </div>
            <IncidentTable incidents={stats.recent} basePath="/admin/incidents" showReporter />
          </div>
        </>
      )}
    </>
  );
}
