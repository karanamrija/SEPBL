import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { EMPTY_FILTERS } from '../constants';
import useIncidentList from '../hooks/useIncidentList';
import IncidentFilters from '../components/IncidentFilters';
import IncidentTable from '../components/IncidentTable';

export default function AdminIncidents() {
  const [params] = useSearchParams();
  const [filters, setFilters] = useState({
    ...EMPTY_FILTERS,
    type: params.get('type') || '',
    severity: params.get('severity') || '',
    status: params.get('status') || '',
  });
  const { incidents, loading, error } = useIncidentList(filters);

  return (
    <>
      <div className="page-header">
        <div>
          <h2>All Incidents</h2>
          <p className="muted">Search, filter and open any incident to manage it. ({incidents.length} shown)</p>
        </div>
      </div>

      <IncidentFilters filters={filters} setFilters={setFilters} />
      {error && <div className="alert alert-error">{error}</div>}

      <div className="card">
        {loading ? <div className="empty">Loading...</div> : <IncidentTable incidents={incidents} basePath="/admin/incidents" showReporter emptyText="No incidents match your filters." />}
      </div>
    </>
  );
}
