import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { getErrorMessage } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { SEVERITIES, TRANSITIONS, isAdminRole } from '../constants';
import { SeverityBadge, StatusBadge } from '../components/Badges';
import StatusTracker from '../components/StatusTracker';
import { formatDate, formatDateTime, formatTime } from '../utils/format';

const Field = ({ label, children }) => (
  <div className="field">
    <div className="field-label">{label}</div>
    <div className="field-value">{children || '—'}</div>
  </div>
);

export default function IncidentDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const admin = isAdminRole(user.role);
  const backPath = admin ? '/admin/incidents' : '/my-incidents';

  const [data, setData] = useState(null);
  const [staff, setStaff] = useState([]);
  const [error, setError] = useState('');
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const [severity, setSeverity] = useState('');
  const [assignee, setAssignee] = useState('');
  const [nextStatus, setNextStatus] = useState('');
  const [resolution, setResolution] = useState('');
  const [note, setNote] = useState('');

  const load = useCallback(async () => {
    try {
      const { data: d } = await api.get(`/incidents/${id}`);
      setData(d);
      const inc = d.incident;
      setSeverity(inc.severity);
      setAssignee(inc.assigned_to ? String(inc.assigned_to) : '');
      setNextStatus((TRANSITIONS[inc.status] || [])[0] || '');
      setResolution(inc.resolution || '');
      setError('');
    } catch (err) {
      setError(getErrorMessage(err));
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (admin) {
      api.get('/users/staff').then((r) => setStaff(r.data.users)).catch(() => {});
    }
  }, [admin]);

  const run = async (fn, okText) => {
    setBusy(true);
    setMsg(null);
    try {
      await fn();
      setMsg({ type: 'success', text: okText });
      await load();
    } catch (err) {
      setMsg({ type: 'error', text: getErrorMessage(err) });
    } finally {
      setBusy(false);
    }
  };

  const updateSeverity = () => run(() => api.put(`/incidents/${id}`, { severity }), 'Severity updated.');

  const assign = () => {
    if (!assignee) return setMsg({ type: 'error', text: 'Please select a staff member.' });
    return run(() => api.put(`/incidents/${id}/assign`, { assigned_to: Number(assignee) }), 'Incident assigned successfully.');
  };

  const updateStatus = () => {
    if (!nextStatus) return setMsg({ type: 'error', text: 'No further status change is available.' });
    return run(
      () => api.put(`/incidents/${id}/status`, { status: nextStatus, resolution }),
      `Status changed to "${nextStatus}".`
    );
  };

  const addNote = (e) => {
    e.preventDefault();
    return run(async () => {
      await api.post(`/incidents/${id}/notes`, { note });
      setNote('');
    }, 'Investigation note added.');
  };

  const deleteIncident = async () => {
    if (!window.confirm('Permanently delete this incident? This cannot be undone.')) return;
    try {
      await api.delete(`/incidents/${id}`);
      navigate('/admin/incidents');
    } catch (err) {
      setMsg({ type: 'error', text: getErrorMessage(err) });
    }
  };

  if (error && !data) {
    return (
      <div className="card">
        <div className="alert alert-error">{error}</div>
        <Link to={backPath} className="btn btn-outline">← Back</Link>
      </div>
    );
  }
  if (!data) return <div className="empty">Loading...</div>;

  const { incident: inc, notes, history } = data;
  const allowedNext = TRANSITIONS[inc.status] || [];

  return (
    <>
      <div className="page-header">
        <div>
          <Link to={backPath} className="back-link">← Back to incidents</Link>
          <h2>
            <span className="mono">{inc.incident_id}</span> — {inc.title}
          </h2>
          <div className="badge-row">
            <StatusBadge value={inc.status} />
            <SeverityBadge value={inc.severity} />
            <span className="badge type-badge">{inc.type}</span>
          </div>
        </div>
      </div>

      {msg && <div className={`alert ${msg.type === 'success' ? 'alert-success' : 'alert-error'}`}>{msg.text}</div>}

      <div className="card">
        <h3 className="card-title">Incident Lifecycle</h3>
        <StatusTracker status={inc.status} />
      </div>

      <div className={admin ? 'detail-layout' : ''}>
        <div className="detail-main">
          <div className="card">
            <h3 className="card-title">Incident Information</h3>
            <div className="info-grid">
              <Field label="Incident ID"><span className="mono">{inc.incident_id}</span></Field>
              <Field label="Reporter">{inc.reporter_name}</Field>
              {admin && <Field label="Reporter Email">{inc.reporter_email}</Field>}
              {admin && <Field label="Department">{inc.reporter_department}</Field>}
              <Field label="Incident Type">{inc.type}</Field>
              <Field label="Date / Time">{formatDate(inc.incident_date)} {formatTime(inc.incident_time)}</Field>
              <Field label="Location / System">{inc.location}</Field>
              <Field label="Assigned Staff">{inc.assigned_name}</Field>
              <Field label="Created At">{formatDateTime(inc.created_at)}</Field>
              <Field label="Last Updated">{formatDateTime(inc.updated_at)}</Field>
              <Field label="Evidence">
                {inc.evidence ? (
                  <a href={`/uploads/${inc.evidence}`} target="_blank" rel="noreferrer">📎 View attachment</a>
                ) : null}
              </Field>
            </div>
            <div className="field-label" style={{ marginTop: 16 }}>Description</div>
            <p className="description">{inc.description}</p>
          </div>

          {inc.resolution && (
            <div className="card resolution-card">
              <h3 className="card-title">Resolution Details</h3>
              <p className="description">{inc.resolution}</p>
            </div>
          )}

          {admin && (
            <div className="card">
              <h3 className="card-title">Investigation Notes</h3>
              {notes.length === 0 && <div className="empty">No notes added yet.</div>}
              {notes.map((n) => (
                <div className="note" key={n.id}>
                  <div className="note-meta">
                    <strong>{n.admin_name}</strong> · {formatDateTime(n.created_at)}
                  </div>
                  <div>{n.note}</div>
                </div>
              ))}
              <form onSubmit={addNote} style={{ marginTop: 14 }}>
                <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add an investigation note..." required />
                <button className="btn btn-primary" style={{ marginTop: 10 }} disabled={busy}>Add Note</button>
              </form>
            </div>
          )}

          <div className="card">
            <h3 className="card-title">Incident History</h3>
            <div className="timeline">
              {history.map((h) => (
                <div className="titem" key={h.id}>
                  <div className="tdot-small" />
                  <div>
                    <strong>{h.action}</strong>
                    {h.new_value ? <span> — {h.old_value ? `${h.old_value} → ` : ''}{h.new_value}</span> : null}
                    <div className="muted small">{h.user_name} · {formatDateTime(h.created_at)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {admin && (
          <div className="detail-side">
            <div className="card">
              <h3 className="card-title">Manage Incident</h3>

              <div className="form-group">
                <label>Severity</label>
                <div className="inline-form">
                  <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
                    {SEVERITIES.map((s) => <option key={s}>{s}</option>)}
                  </select>
                  <button className="btn btn-outline" onClick={updateSeverity} disabled={busy || severity === inc.severity}>Update</button>
                </div>
              </div>

              <div className="form-group">
                <label>Assign to Security Staff</label>
                <div className="inline-form">
                  <select value={assignee} onChange={(e) => setAssignee(e.target.value)} disabled={inc.status === 'Closed'}>
                    <option value="">Select staff...</option>
                    {staff.map((s) => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                  <button className="btn btn-outline" onClick={assign} disabled={busy || inc.status === 'Closed'}>Assign</button>
                </div>
              </div>

              <div className="form-group">
                <label>Change Status</label>
                {allowedNext.length === 0 ? (
                  <div className="muted">This incident is closed. No further changes.</div>
                ) : (
                  <>
                    <select value={nextStatus} onChange={(e) => setNextStatus(e.target.value)}>
                      {allowedNext.map((s) => <option key={s}>{s}</option>)}
                    </select>
                    {nextStatus === 'Resolved' && (
                      <textarea
                        rows={4}
                        style={{ marginTop: 10 }}
                        value={resolution}
                        onChange={(e) => setResolution(e.target.value)}
                        placeholder="Resolution details (required to resolve)..."
                      />
                    )}
                    <button
                      className={`btn ${nextStatus === 'Closed' ? 'btn-success' : 'btn-primary'} btn-block`}
                      style={{ marginTop: 10 }}
                      onClick={updateStatus}
                      disabled={busy}
                    >
                      {nextStatus === 'Closed' ? 'Close Incident' : nextStatus === 'Resolved' ? 'Resolve Incident' : `Set to ${nextStatus}`}
                    </button>
                    <small className="muted">
                      Lifecycle: New → Assigned → Under Investigation → Resolved → Closed
                    </small>
                  </>
                )}
              </div>

              {user.role === 'admin' && (
                <button className="btn btn-danger btn-block" onClick={deleteIncident}>Delete Incident</button>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
