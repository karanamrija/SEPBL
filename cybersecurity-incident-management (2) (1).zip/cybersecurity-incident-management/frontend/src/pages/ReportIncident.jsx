import { useState } from 'react';
import { Link } from 'react-router-dom';
import api, { getErrorMessage } from '../services/api';
import { INCIDENT_TYPES, SEVERITIES } from '../constants';
import { nowTimeStr, todayStr } from '../utils/format';

const initialForm = () => ({
  title: '',
  type: 'Phishing',
  description: '',
  incident_date: todayStr(),
  incident_time: nowTimeStr(),
  severity: 'Medium',
  location: '',
});

export default function ReportIncident() {
  const [form, setForm] = useState(initialForm());
  const [file, setFile] = useState(null);
  const [fileKey, setFileKey] = useState(0);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState(null);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const reset = () => {
    setForm(initialForm());
    setFile(null);
    setFileKey((k) => k + 1);
    setError('');
  };

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (file) fd.append('evidence', file);
      const { data } = await api.post('/incidents', fd);
      setCreated(data.incident);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  if (created) {
    return (
      <div className="card success-card">
        <div className="success-icon">✅</div>
        <h2>Incident reported successfully.</h2>
        <p className="muted">Your incident has been recorded and sent to the security team.</p>
        <div className="incident-id-box">{created.incident_id}</div>
        <p className="muted">Keep this Incident ID for future reference.</p>
        <div className="btn-row center">
          <Link to={`/incidents/${created.id}`} className="btn btn-primary">View Incident</Link>
          <button
            className="btn btn-outline"
            onClick={() => {
              setCreated(null);
              reset();
            }}
          >
            Report Another
          </button>
          <Link to="/dashboard" className="btn btn-outline">Go to Dashboard</Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="page-header">
        <div>
          <h2>Report a Cybersecurity Incident</h2>
          <p className="muted">Provide as much detail as possible. Do not include your password in the report.</p>
        </div>
      </div>

      <form className="card" onSubmit={submit}>
        {error && <div className="alert alert-error">{error}</div>}

        <div className="form-group">
          <label>Incident Title *</label>
          <input value={form.title} onChange={(e) => set('title', e.target.value)} placeholder="e.g. Phishing email asking for portal password" maxLength={150} required />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Incident Type *</label>
            <select value={form.type} onChange={(e) => set('type', e.target.value)}>
              {INCIDENT_TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label>Severity (your estimate) *</label>
            <select value={form.severity} onChange={(e) => set('severity', e.target.value)}>
              {SEVERITIES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="form-group">
          <label>Description *</label>
          <textarea rows={5} value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="Describe what happened, how you noticed it, and what actions you took." required />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Date of Incident *</label>
            <input type="date" value={form.incident_date} onChange={(e) => set('incident_date', e.target.value)} required />
          </div>
          <div className="form-group">
            <label>Time of Incident *</label>
            <input type="time" value={form.incident_time} onChange={(e) => set('incident_time', e.target.value)} required />
          </div>
        </div>

        <div className="form-group">
          <label>Location / System Affected *</label>
          <input value={form.location} onChange={(e) => set('location', e.target.value)} placeholder="e.g. College Email, Library PC-12, Student Portal" maxLength={150} required />
        </div>

        <div className="form-group">
          <label>Evidence (optional)</label>
          <input key={fileKey} type="file" accept=".png,.jpg,.jpeg,.gif,.pdf,.txt,.doc,.docx" onChange={(e) => setFile(e.target.files[0] || null)} />
          <small className="muted">Screenshots or documents: PNG, JPG, GIF, PDF, TXT, DOC, DOCX (max 5 MB)</small>
        </div>

        <div className="btn-row">
          <button className="btn btn-primary" disabled={loading}>{loading ? 'Submitting...' : 'Submit Report'}</button>
          <button type="button" className="btn btn-outline" onClick={reset}>Reset</button>
        </div>
      </form>
    </>
  );
}
