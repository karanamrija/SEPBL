import { useCallback, useEffect, useState } from 'react';
import api, { getErrorMessage } from '../services/api';
import { ROLE_LABELS } from '../constants';
import { formatDateTime } from '../utils/format';

const emptyForm = { name: '', email: '', password: '', role: 'user', department: '' };

export default function ManageUsers() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(() => {
    api.get('/users')
      .then((r) => setUsers(r.data.users))
      .catch((e) => setMsg({ type: 'error', text: getErrorMessage(e) }));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMsg(null);
    try {
      await api.post('/users', form);
      setMsg({ type: 'success', text: 'User created successfully.' });
      setForm(emptyForm);
      load();
    } catch (err) {
      setMsg({ type: 'error', text: getErrorMessage(err) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="page-header">
        <div>
          <h2>Manage Users</h2>
          <p className="muted">View registered users and add new students, staff or security personnel.</p>
        </div>
      </div>

      {msg && <div className={`alert ${msg.type === 'success' ? 'alert-success' : 'alert-error'}`}>{msg.text}</div>}

      <form className="card" onSubmit={submit}>
        <h3 className="card-title">Add New User</h3>
        <div className="form-row">
          <div className="form-group">
            <label>Full Name *</label>
            <input value={form.name} onChange={(e) => set('name', e.target.value)} required />
          </div>
          <div className="form-group">
            <label>Email *</label>
            <input type="email" value={form.email} onChange={(e) => set('email', e.target.value)} required />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label>Password * (min 6 characters)</label>
            <input type="password" value={form.password} onChange={(e) => set('password', e.target.value)} minLength={6} required />
          </div>
          <div className="form-group">
            <label>Role *</label>
            <select value={form.role} onChange={(e) => set('role', e.target.value)}>
              <option value="user">Student / Staff</option>
              <option value="security">Security Staff</option>
              <option value="admin">Security Administrator</option>
            </select>
          </div>
        </div>
        <div className="form-group">
          <label>Department</label>
          <input value={form.department} onChange={(e) => set('department', e.target.value)} />
        </div>
        <button className="btn btn-primary" disabled={loading}>{loading ? 'Saving...' : 'Create User'}</button>
      </form>

      <div className="card">
        <h3 className="card-title">All Users ({users.length})</h3>
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Created</th></tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td><span className={`badge role-${u.role}`}>{ROLE_LABELS[u.role]}</span></td>
                  <td>{u.department || '—'}</td>
                  <td>{formatDateTime(u.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
