import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const DIAGRAMS = [
  { title: 'Use Case Diagram', desc: 'Actors (Student/Staff, Security Staff, Admin) and what each can do in the system.', images: [{ label: 'Use Case', file: '01-use-case-diagram' }] },
  { title: 'Class Diagram', desc: 'Classes and relationships matching the database tables: User, Incident, IncidentNote, IncidentHistory.', images: [{ label: 'Class', file: '02-class-diagram' }] },
  { title: 'Activity Diagram', desc: 'Workflow from reporting an incident to closing it, across Student, System and Admin.', images: [{ label: 'Activity', file: '03-activity-diagram' }] },
  { title: 'Sequence Diagram', desc: 'Message flow for reporting an incident and for admin assignment and status updates.', images: [{ label: 'Sequence', file: '04-sequence-diagram' }] },
  { title: 'Component Diagram', desc: 'React frontend, Express backend (routes, middleware, controllers, models), MySQL and file storage.', images: [{ label: 'Component', file: '05-component-diagram' }] },
  { title: 'Deployment Diagram', desc: 'Browser, Node.js (Vite + Express) and MySQL deployment nodes.', images: [{ label: 'Deployment', file: '06-deployment-diagram' }] },
  {
    title: 'Data Flow Diagram (DFD)',
    desc: 'Level 0 shows the whole system as one process. Level 1 breaks it into seven processes and five data stores.',
    images: [
      { label: 'Level 0', file: '07a-dfd-level0' },
      { label: 'Level 1', file: '07b-dfd-level1' },
    ],
  },
  { title: 'Software Architecture Diagram', desc: 'Three-tier architecture: Presentation (React), Application (Express), Data (MySQL).', images: [{ label: 'Architecture', file: '08-software-architecture' }] },
];

export default function Diagrams({ standalone = false }) {
  const { user } = useAuth();
  const [active, setActive] = useState(0);
  const [sub, setSub] = useState(0);

  const d = DIAGRAMS[active];
  const img = d.images[Math.min(sub, d.images.length - 1)];
  const src = `/diagrams/${img.file}.png`;

  const select = (i) => {
    setActive(i);
    setSub(0);
  };

  const content = (
    <>
      <div className="page-header">
        <div>
          <h2>Project Diagrams</h2>
          <p className="muted">Software Engineering PBL: click a diagram to view it.</p>
        </div>
      </div>

      <div className="diagram-layout">
        <div className="card diagram-menu">
          {DIAGRAMS.map((item, i) => (
            <button key={item.title} className={`diagram-tab ${i === active ? 'active' : ''}`} onClick={() => select(i)}>
              <span className="diagram-no">{i + 1}</span> {item.title}
            </button>
          ))}
        </div>

        <div className="card diagram-view">
          <div className="card-head">
            <h3 className="card-title">{active + 1}. {d.title}</h3>
            <div className="btn-row">
              <button className="btn btn-sm btn-outline" disabled={active === 0} onClick={() => select(active - 1)}>← Previous</button>
              <button className="btn btn-sm btn-outline" disabled={active === DIAGRAMS.length - 1} onClick={() => select(active + 1)}>Next →</button>
            </div>
          </div>
          <p className="muted">{d.desc}</p>

          {d.images.length > 1 && (
            <div className="btn-row" style={{ margin: '12px 0' }}>
              {d.images.map((im, i) => (
                <button key={im.file} className={`btn btn-sm ${i === sub ? 'btn-primary' : 'btn-outline'}`} onClick={() => setSub(i)}>
                  {im.label}
                </button>
              ))}
            </div>
          )}

          <div className="diagram-frame">
            <a href={src} target="_blank" rel="noreferrer" title="Click to open full size">
              <img src={src} alt={`${d.title} ${img.label}`} />
            </a>
          </div>

          <div className="btn-row" style={{ marginTop: 14 }}>
            <a className="btn btn-sm btn-outline" href={src} target="_blank" rel="noreferrer">Open full size</a>
            <a className="btn btn-sm btn-outline" href={src} download>Download PNG</a>
            <a className="btn btn-sm btn-outline" href={`/diagrams/${img.file}.svg`} target="_blank" rel="noreferrer">Open SVG</a>
          </div>
        </div>
      </div>
    </>
  );

  if (standalone) {
    return (
      <div className="standalone-page">
        <header className="standalone-header">
          <strong>🛡️ CyberShield</strong>
          <Link to={user ? '/' : '/login'} className="btn btn-sm btn-outline">{user ? '← Back to Dashboard' : '← Back to Login'}</Link>
        </header>
        <div className="content">{content}</div>
      </div>
    );
  }
  return content;
}
