import { useState } from 'react';
import { Link } from 'react-router-dom';
import { EMPTY_FILTERS } from '../constants';
import useIncidentList from '../hooks/useIncidentList';
import IncidentFilters from '../components/IncidentFilters';
import IncidentTable from '../components/IncidentTable';

export default function MyIncidents() {
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const { incidents, loading, error } = useIncidentList(filters);

  return (
    <>
      <div className="page-header">
        <div>
          <h2>My Incidents</h2>
          <p className="muted">All incidents you have reported.</p>
        </div>
        <Link to="/report" className="btn btn-primary">+ Report New Incident</Link>
      </div>

      <IncidentFilters filters={filters} setFilters={setFilters} />
      {error && <div className="alert alert-error">{error}</div>}

      <div className="card">
        {loading ? <div className="empty">Loading...</div> : <IncidentTable incidents={incidents} basePath="/incidents" emptyText="No incidents match your filters." />}
      </div>
    </>
  );
}
