import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getErrorMessage } from '../services/api';
import { isAdminRole } from '../constants';

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to={isAdminRole(user.role) ? '/admin' : '/dashboard'} replace />;

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const u = await login(email.trim(), password);
      navigate(isAdminRole(u.role) ? '/admin' : '/dashboard', { replace: true });
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const fill = (e, p) => {
    setEmail(e);
    setPassword(p);
    setError('');
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-head">
          <div className="login-logo">🛡️</div>
          <h1>CyberShield</h1>
          <p>College Cybersecurity Incident Management Portal</p>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={submit}>
          <div className="form-group">
            <label>College Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@college.com" required />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" required />
          </div>
          <button className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <div className="demo-box">
          <strong>Demo accounts (click to fill)</strong>
          <div className="demo-buttons">
            <button type="button" className="btn btn-sm btn-outline" onClick={() => fill('student@college.com', 'student123')}>Student</button>
            <button type="button" className="btn btn-sm btn-outline" onClick={() => fill('admin@college.com', 'admin123')}>Admin</button>
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: 16 }}>
          <Link to="/diagrams-view">📐 View Project Diagrams (UML, DFD, Architecture)</Link>
        </div>
      </div>
    </div>
  );
}
