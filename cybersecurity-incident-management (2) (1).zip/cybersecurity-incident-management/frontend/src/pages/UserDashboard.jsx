import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { getErrorMessage } from '../services/api';
import { useAuth } from '../context/AuthContext';
import StatCard from '../components/StatCard';
import IncidentTable from '../components/IncidentTable';

export default function UserDashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/dashboard/stats')
      .then((r) => setStats(r.data))
      .catch((e) => setError(getErrorMessage(e)));
  }, []);

  return (
    <>
      <div className="page-header">
        <div>
          <h2>Welcome back, {user.name} 👋</h2>
          <p className="muted">Report cybersecurity incidents and track their progress.</p>
        </div>
        <Link to="/report" className="btn btn-primary">+ Report New Incident</Link>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {stats && (
        <>
          <div className="stats-grid">
            <StatCard label="Total Reported" value={stats.totals.total} icon="📋" color="blue" />
            <StatCard label="New Incidents" value={stats.totals.new} icon="🆕" color="cyan" />
            <StatCard label="Under Investigation" value={stats.totals.underInvestigation} icon="🔍" color="orange" />
            <StatCard label="Resolved" value={stats.totals.resolved + stats.totals.closed} icon="✅" color="green" />
          </div>

          <div className="card">
            <div className="card-head">
              <h3 className="card-title">Recent Incidents</h3>
              <Link to="/my-incidents">View all →</Link>
            </div>
            <IncidentTable incidents={stats.recent} basePath="/incidents" emptyText="You have not reported any incidents yet." />
          </div>
        </>
      )}
    </>
  );
}
