import { useEffect, useState } from 'react';
import api, { getErrorMessage } from '../services/api';
import { ROLE_LABELS } from '../constants';
import { formatDateTime } from '../utils/format';

export default function Profile() {
  const [me, setMe] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/auth/me')
      .then((r) => setMe(r.data.user))
      .catch((e) => setError(getErrorMessage(e)));
  }, []);

  return (
    <>
      <div className="page-header">
        <h2>My Profile</h2>
      </div>
      {error && <div className="alert alert-error">{error}</div>}
      {me && (
        <div className="card profile-card">
          <div className="avatar big">{me.name.charAt(0).toUpperCase()}</div>
          <div className="info-grid">
            <div className="field"><div className="field-label">Full Name</div><div className="field-value">{me.name}</div></div>
            <div className="field"><div className="field-label">Email</div><div className="field-value">{me.email}</div></div>
            <div className="field"><div className="field-label">Role</div><div className="field-value">{ROLE_LABELS[me.role]}</div></div>
            <div className="field"><div className="field-label">Department</div><div className="field-value">{me.department || '—'}</div></div>
            <div className="field"><div className="field-label">Member Since</div><div className="field-value">{formatDateTime(me.created_at)}</div></div>
          </div>
        </div>
      )}
    </>
  );
}
