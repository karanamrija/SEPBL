import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { isAdminRole } from './constants';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import UserDashboard from './pages/UserDashboard';
import ReportIncident from './pages/ReportIncident';
import MyIncidents from './pages/MyIncidents';
import IncidentDetails from './pages/IncidentDetails';
import Profile from './pages/Profile';
import AdminDashboard from './pages/AdminDashboard';
import AdminIncidents from './pages/AdminIncidents';
import ManageUsers from './pages/ManageUsers';
import Diagrams from './pages/Diagrams';
import NotFound from './pages/NotFound';

function Home() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return <Navigate to={isAdminRole(user.role) ? '/admin' : '/dashboard'} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/diagrams-view" element={<Diagrams standalone />} />

      <Route element={<Layout />}>
        {/* Student / staff pages */}
        <Route path="/dashboard" element={<ProtectedRoute admin={false}><UserDashboard /></ProtectedRoute>} />
        <Route path="/report" element={<ProtectedRoute admin={false}><ReportIncident /></ProtectedRoute>} />
        <Route path="/my-incidents" element={<ProtectedRoute admin={false}><MyIncidents /></ProtectedRoute>} />
        <Route path="/incidents/:id" element={<ProtectedRoute admin={false}><IncidentDetails /></ProtectedRoute>} />

        {/* Shared pages */}
        <Route path="/diagrams" element={<ProtectedRoute><Diagrams /></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />

        {/* Admin / security pages */}
        <Route path="/admin" element={<ProtectedRoute admin={true}><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/incidents" element={<ProtectedRoute admin={true}><AdminIncidents /></ProtectedRoute>} />
        <Route path="/admin/incidents/:id" element={<ProtectedRoute admin={true}><IncidentDetails /></ProtectedRoute>} />
        <Route path="/admin/users" element={<ProtectedRoute admin={true}><ManageUsers /></ProtectedRoute>} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
