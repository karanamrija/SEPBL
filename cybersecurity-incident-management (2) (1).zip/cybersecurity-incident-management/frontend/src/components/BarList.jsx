import { slug } from '../utils/format';

export default function BarList({ title, data }) {
  const max = Math.max(1, ...data.map((d) => d.count));
  return (
    <div className="card">
      <h3 className="card-title">{title}</h3>
      {data.length === 0 && <div className="empty">No data yet.</div>}
      <div className="bars">
        {data.map((d) => (
          <div className="bar-row" key={d.label}>
            <div className="bar-label">{d.label}</div>
            <div className="bar-track">
              <div className={`bar-fill fill-${slug(d.label)}`} style={{ width: `${(d.count / max) * 100}%` }} />
            </div>
            <div className="bar-count">{d.count}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
