import { slug } from '../utils/format';

export const StatusBadge = ({ value }) => <span className={`badge st-${slug(value)}`}>{value}</span>;

export const SeverityBadge = ({ value }) => <span className={`badge sev-${slug(value)}`}>{value}</span>;
