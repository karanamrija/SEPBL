import { Link } from 'react-router-dom';

export default function StatCard({ label, value, icon, color = 'blue', to }) {
  const body = (
    <>
      <div className={`stat-icon c-${color}`}>{icon}</div>
      <div>
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
      </div>
    </>
  );
  return to ? (
    <Link to={to} className="card stat-card clickable">{body}</Link>
  ) : (
    <div className="card stat-card">{body}</div>
  );
}
