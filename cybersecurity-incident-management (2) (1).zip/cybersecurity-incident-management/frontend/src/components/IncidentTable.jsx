import { Link } from 'react-router-dom';
import { SeverityBadge, StatusBadge } from './Badges';
import { formatDate } from '../utils/format';

export default function IncidentTable({ incidents, basePath, showReporter = false, emptyText = 'No incidents found.' }) {
  if (!incidents.length) return <div className="empty">{emptyText}</div>;
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Incident ID</th>
            <th>Title</th>
            <th>Type</th>
            {showReporter && <th>Reporter</th>}
            <th>Severity</th>
            <th>Status</th>
            <th>Date</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {incidents.map((i) => (
            <tr key={i.id}>
              <td><Link to={`${basePath}/${i.id}`} className="mono">{i.incident_id}</Link></td>
              <td className="title-cell">{i.title}</td>
              <td>{i.type}</td>
              {showReporter && <td>{i.reporter_name}</td>}
              <td><SeverityBadge value={i.severity} /></td>
              <td><StatusBadge value={i.status} /></td>
              <td>{formatDate(i.incident_date)}</td>
              <td><Link className="btn btn-sm btn-outline" to={`${basePath}/${i.id}`}>View</Link></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
