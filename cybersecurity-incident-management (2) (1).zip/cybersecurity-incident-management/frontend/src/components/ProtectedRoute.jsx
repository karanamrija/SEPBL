import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { isAdminRole } from '../constants';

// admin={true}  -> only admin/security
// admin={false} -> only student/staff
// admin omitted -> any logged-in user
export default function ProtectedRoute({ children, admin }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  const isAdmin = isAdminRole(user.role);
  if (admin === true && !isAdmin) return <Navigate to="/dashboard" replace />;
  if (admin === false && isAdmin) return <Navigate to="/admin" replace />;
  return children;
}
