import { EMPTY_FILTERS, INCIDENT_TYPES, SEVERITIES, STATUSES } from '../constants';

export default function IncidentFilters({ filters, setFilters }) {
  const set = (key, value) => setFilters((f) => ({ ...f, [key]: value }));

  return (
    <div className="card filters">
      <input
        type="text"
        placeholder="🔍 Search by ID, title, description or reporter..."
        value={filters.search}
        onChange={(e) => set('search', e.target.value)}
        className="filter-search"
      />
      <select value={filters.type} onChange={(e) => set('type', e.target.value)}>
        <option value="">All Types</option>
        {INCIDENT_TYPES.map((t) => <option key={t}>{t}</option>)}
      </select>
      <select value={filters.severity} onChange={(e) => set('severity', e.target.value)}>
        <option value="">All Severities</option>
        {SEVERITIES.map((s) => <option key={s}>{s}</option>)}
      </select>
      <select value={filters.status} onChange={(e) => set('status', e.target.value)}>
        <option value="">All Statuses</option>
        {STATUSES.map((s) => <option key={s}>{s}</option>)}
      </select>
      <input type="date" value={filters.date} onChange={(e) => set('date', e.target.value)} title="Incident date" />
      <button className="btn btn-outline" onClick={() => setFilters(EMPTY_FILTERS)}>Clear</button>
    </div>
  );
}
