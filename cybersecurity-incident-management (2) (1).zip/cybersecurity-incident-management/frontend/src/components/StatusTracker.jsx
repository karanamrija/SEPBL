import { STATUSES } from '../constants';

export default function StatusTracker({ status }) {
  const current = STATUSES.indexOf(status);
  return (
    <div className="tracker">
      {STATUSES.map((s, i) => (
        <div key={s} className={`tstep ${i < current ? 'done' : ''} ${i === current ? 'active' : ''}`}>
          <div className="tdot">{i < current ? '✓' : i + 1}</div>
          <div className="tlabel">{s}</div>
        </div>
      ))}
    </div>
  );
}
