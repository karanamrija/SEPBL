import { useState } from 'react';
import { NavLink, Navigate, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ROLE_LABELS, isAdminRole } from '../constants';

const USER_LINKS = [
  { to: '/dashboard', label: 'Dashboard', icon: '📊' },
  { to: '/report', label: 'Report Incident', icon: '🚨' },
  { to: '/my-incidents', label: 'My Incidents', icon: '📁' },
  { to: '/diagrams', label: 'Diagrams', icon: '🗺️' },
  { to: '/profile', label: 'Profile', icon: '👤' },
];

const ADMIN_LINKS = [
  { to: '/admin', label: 'Dashboard', icon: '📊', end: true },
  { to: '/admin/incidents', label: 'All Incidents', icon: '🗂️' },
  { to: '/admin/users', label: 'Users', icon: '👥' },
  { to: '/diagrams', label: 'Diagrams', icon: '🗺️' },
  { to: '/profile', label: 'Profile', icon: '👤' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  if (!user) return <Navigate to="/login" replace />;

  const links = isAdminRole(user.role) ? ADMIN_LINKS : USER_LINKS;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="brand">
          <span className="brand-icon">🛡️</span>
          <div>
            <div className="brand-name">CyberShield</div>
            <div className="brand-sub">College Incident Portal</div>
          </div>
        </div>
        <nav className="nav">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              onClick={() => setOpen(false)}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              <span>{l.icon}</span> {l.label}
            </NavLink>
          ))}
        </nav>
        <button className="nav-link logout-link" onClick={handleLogout}>
          <span>🚪</span> Logout
        </button>
      </aside>

      {open && <div className="overlay" onClick={() => setOpen(false)} />}

      <div className="main">
        <header className="topbar">
          <button className="hamburger" onClick={() => setOpen(!open)} aria-label="Menu">☰</button>
          <div className="topbar-title">Cybersecurity Incident Management System</div>
          <div className="user-chip">
            <div className="avatar">{user.name.charAt(0).toUpperCase()}</div>
            <div className="user-meta">
              <strong>{user.name}</strong>
              <small>{ROLE_LABELS[user.role]}</small>
            </div>
            <button className="btn btn-sm btn-outline" onClick={handleLogout}>Logout</button>
          </div>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
