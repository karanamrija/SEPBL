import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const url = error.config?.url || '';
    if (error.response?.status === 401 && !url.includes('/auth/login')) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export function getErrorMessage(err) {
  const data = err.response?.data;
  if (data?.message) {
    return data.errors && data.errors.length ? `${data.message} ${data.errors.join(' ')}` : data.message;
  }
  if (err.request) return 'Cannot reach the server. Make sure the backend is running on port 5000.';
  return 'Something went wrong. Please try again.';
}

export default api;
